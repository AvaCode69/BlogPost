# About this project

Blog Post is a project in that users can post content by form. in the right part of the Home page is shown the newest posts. Blog page is shown all posts by pagination(from newest to oldest).

## Some features are :

- users couldn't send the empty form if files be emty , error message is shown to users.

  -Error message disappear after 5 seconds
  -when users press load more button a lot , after loading all posts, finally there is shown (No more posts to show) message to users

## Stack

React Js, NodeJS,Bootstrap </br></br>

## Not completed feature:

- handleing errors better
  -using Material UI instead of bootstrap
  -using TypeScripe
  - making Structured, reusable code more
    -Writing better unit tests

## Linke of live Demo

https://blogpost69.netlify.app/

## Some screenshots:

<img width="350px" src="https://user-images.githubusercontent.com/122700888/217621055-e8fe3cf4-c905-41e7-86b2-11bee1c61292.png"></img>
<img width="350px" src="https://user-images.githubusercontent.com/122700888/217621868-fc051ae3-4645-41c8-8805-53d3705353c2.png"></img></br></br>
