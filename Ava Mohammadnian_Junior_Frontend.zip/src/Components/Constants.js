export const BASEURL = "https://frontend-case-api.sbdev.nl/api";
export const APIKEY = "pj11daaQRz7zUIH56B9Z";
export const PostUrl = `${BASEURL}/posts`;
export const CategoryUrl = `${BASEURL}/categories`;
