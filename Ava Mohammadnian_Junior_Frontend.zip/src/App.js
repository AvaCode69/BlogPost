import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import React, { Component } from "react";
import NavBars from "./Components/NavBars";

function App() {
  return <NavBars />;
}

export default App;
